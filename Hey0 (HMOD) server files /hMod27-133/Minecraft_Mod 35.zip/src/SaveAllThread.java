/* Save-alls every x minutes according to settings */

public class SaveAllThread implements Runnable {
    private boolean running = false;

    public void run() {
        while (this.running) {
            try {
                Thread.sleep(etc.getInstance().saveInterval);
            } catch (InterruptedException localInterruptedException) {
            }
            etc.getServer().a("save-all", etc.getServer());
        }
    }

    public void start() {
        this.running = true;
        new Thread(this).start();
    }

    public void stop() {
        this.running = false;
    }
}
