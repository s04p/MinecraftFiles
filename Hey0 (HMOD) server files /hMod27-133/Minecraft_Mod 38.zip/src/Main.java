
public class Main {
    public static void main(String[] args) {
        net.minecraft.server.MinecraftServer.main(args);
    }
}
