/* Flat file data source */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.logging.Level;

public class FlatFileSource extends DataSource {
    public void initialize() {
        loadUsers();
        loadGroups();
        loadKits();
        loadHomes();
        loadWarps();
        loadItems();
    }

    public void loadUsers() {
        String location = etc.getInstance().usersLoc;

        if (!new File(location).exists()) {
            FileWriter writer = null;
            try {
                writer = new FileWriter(location);
                writer.write("#Add your users here (When adding your entry DO NOT include #!)\r\n");
                writer.write("#The format is:\r\n");
                writer.write("#NAME:GROUPS:ADMIN/UNRESTRICTED:COLOR:COMMANDS\r\n");
                writer.write("#For administrative powers set admin/unrestricted to 2.\r\n");
                writer.write("#For no restrictions and ability to give out items set it to 1.\r\n");
                writer.write("#If you don't want the person to be able to build set it to -1.\r\n");
                writer.write("#Admin/unrestricted, color and commands are optional.\r\n");
                writer.write("#Examples:\r\n");
                writer.write("#Adminfoo:admins\r\n");
                writer.write("#Moderator39:mods:1:§0:/unban\r\n");
                writer.write("#BobTheBuilder:vip:0:§d\r\n");
            } catch (Exception e) {
                log.log(Level.SEVERE, "Exception while creating " + location, e);
            } finally {
                try {
                    if (writer != null) {
                        writer.close();
                    }
                } catch (IOException e) {
                    log.log(Level.SEVERE, "Exception while closing writer for " + location, e);
                }
            }
        }

        synchronized (userLock) {
            users = new ArrayList<User>();
            try {
                Scanner scanner = new Scanner(new File(location));
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.startsWith("#") || line.equals("") || line.startsWith("﻿")) {
                        continue;
                    }
                    String[] split = line.split(":");

                    User user = new User();
                    user.Name = split[0];
                    user.Groups = split[1].split(",");

                    if (split.length >= 3) {
                        if (split[2].equals("1")) {
                            user.IgnoreRestrictions = true;
                        } else if (split[2].equals("2")) {
                            user.Administrator = true;
                        } else if (split[2].equals("-1")) {
                            user.CanModifyWorld = false;
                        }
                    }
                    if (split.length >= 4) {
                        user.Prefix = split[3].replace("\\u00A7", "§");
                    }
                    if (split.length >= 5) {
                        user.Commands = split[4].split(",");
                    } else {
                        user.Commands = new String[]{""};
                    }

                    users.add(user);
                }
                scanner.close();
            } catch (Exception e) {
                log.log(Level.SEVERE, "Exception while reading " + location + " (Are you sure you formatted it correctly?)", e);
            }
        }
    }

    public void loadGroups() {
        String location = etc.getInstance().groupLoc;

        if (!new File(location).exists()) {
            FileWriter writer = null;
            try {
                writer = new FileWriter(location);
                writer.write("#Add your groups here (When adding your entry DO NOT include #!)\r\n");
                writer.write("#The format is:\r\n");
                writer.write("#NAME:COLOR:COMMANDS:INHERITEDGROUPS:ADMIN/UNRESTRICTED\r\n");
                writer.write("#For administrative powers set admin/unrestricted to 2.\r\n");
                writer.write("#For no restrictions and ability to give out items set it to 1.\r\n");
                writer.write("#If you don't want the group to be able to build set it to -1.\r\n");
                writer.write("#Inherited groups and admin/unrestricted are optional.\r\n");
                writer.write("#Examples:\r\n");
                writer.write("admins:§c:*:mods:2\r\n");
                writer.write("mods:§b:/ban,/kick,/item,/tp,/tphere,/s,/i,/give:vip:1\r\n");
                writer.write("vip:§a::default\r\n");
                writer.write("default:§f:/help,/sethome,/home,/spawn,/me,/msg,/kit,/playerlist,/warp,/motd,/compass,/tell,/m,/who:default\r\n");
            } catch (Exception e) {
                log.log(Level.SEVERE, "Exception while creating " + location, e);
            } finally {
                try {
                    if (writer != null) {
                        writer.close();
                    }
                } catch (IOException e) {
                    log.log(Level.SEVERE, "Exception while closing writer for " + location, e);
                }
            }
        }

        synchronized (groupLock) {
            groups = new ArrayList<Group>();
            try {
                Scanner scanner = new Scanner(new File(location));
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.startsWith("#") || line.equals("")) {
                        continue;
                    }

                    String[] split = line.split(":");
                    Group group = new Group();
                    group.Name = split[0];
                    group.Prefix = split[1].replace("\\u00A7", "§");
                    group.Commands = split[2].split(",");
                    if (split.length >= 4) {
                        group.InheritedGroups = split[3].split(",");
                    }
                    if (split.length >= 5) {
                        if (split[4].equals("1")) {
                            group.IgnoreRestrictions = true;
                        } else if (split[4].equals("2")) {
                            group.Administrator = true;
                        } else if (split[4].equals("-1")) {
                            group.CanModifyWorld = false;
                        }
                    }

                    // kind of a shitty way, but whatever.
                    if (group.InheritedGroups != null) {
                        if (group.InheritedGroups[0].equalsIgnoreCase(group.Name)) {
                            group.InheritedGroups = new String[1];
                            group.InheritedGroups[0] = "";
                            group.DefaultGroup = true;
                        }
                    }

                    groups.add(group);
                }
                scanner.close();
            } catch (Exception e) {
                log.log(Level.SEVERE, "Exception while reading " + location + " (Are you sure you formatted it correctly?)", e);
            }
        }
    }

    public void loadKits() {
        kits = new ArrayList<Kit>();
        String location = etc.getInstance().kitsLoc;

        if (!new File(location).exists()) {
            FileWriter writer = null;
            try {
                writer = new FileWriter(location);
                writer.write("#Add your kits here. Example entry below (When adding your entry DO NOT include #!)\r\n");
                writer.write("#miningbasics:1,2,3,4:6000\r\n");
                writer.write("#The formats are (Find out more about groups in " + etc.getInstance().usersLoc + ":\r\n");
                writer.write("#NAME:IDs:DELAY\r\n");
                writer.write("#NAME:IDs:DELAY:GROUP\r\n");
                writer.write("#6000 for delay is roughly 5 minutes.\r\n");
            } catch (Exception e) {
                log.log(Level.SEVERE, "Exception while creating " + location, e);
            } finally {
                try {
                    if (writer != null) {
                        writer.close();
                    }
                } catch (IOException e) {
                }
            }
        }

        try {
            Scanner scanner = new Scanner(new File(location));
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.startsWith("#") || line.equals("")) // Skip it.
                {
                    continue;
                }
                String[] split = line.split(":");
                String name = split[0];
                String[] ids = split[1].split(",");
                int delay = Integer.parseInt(split[2]);
                String group = "";
                if (split.length == 4) {
                    group = split[3];
                }
                Kit kit = new Kit();
                kit.Name = name;
                kit.IDs = new HashMap<String, Integer>();
                for (String str : ids) {
                    String id = "";
                    int amount = 1;
                    if (str.contains(" ")) {
                        id = str.split(" ")[0];
                        amount = Integer.parseInt(str.split(" ")[1]);
                    } else {
                        id = str;
                    }
                    kit.IDs.put(id, amount);
                }
                kit.Delay = delay;
                kit.Group = group;
                kits.add(kit);
            }
            scanner.close();
        } catch (Exception e) {
            log.log(Level.SEVERE, "Exception while reading " + location, e);
        }
    }

    public void loadHomes() {
        synchronized (homeLock) {
            homes = new HashMap<String, Location>();
            if (!etc.getInstance().saveHomes) {
                return;
            }

            String location = etc.getInstance().homeLoc;
            if (new File(location).exists()) {
                try {
                    Scanner scanner = new Scanner(new File(location));
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        if (line.startsWith("#") || line.equals("")) {
                            continue;
                        }
                        String[] split = line.split(":");
                        if (split.length < 4) {
                            continue;
                        }
                        Location loc = new Location();
                        loc.x = Double.parseDouble(split[1]);
                        loc.y = Double.parseDouble(split[2]);
                        loc.z = Double.parseDouble(split[3]);
                        if (split.length == 6) {
                            loc.rotX = Float.parseFloat(split[4]);
                            loc.rotY = Float.parseFloat(split[5]);
                        }
                        homes.put(split[0], loc);
                    }
                    scanner.close();
                } catch (Exception e) {
                    log.log(Level.SEVERE, "Exception while reading " + location, e);
                }
            }
        }
    }

    public void loadWarps() {
        synchronized (warpLock) {
            warps = new HashMap<String, Location>();
            String location = etc.getInstance().warpLoc;

            if (new File(location).exists()) {
                try {
                    Scanner scanner = new Scanner(new File(location));
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        if (line.startsWith("#") || line.equals("")) {
                            continue;
                        }
                        String[] split = line.split(":");
                        if (split.length < 4) {
                            continue;
                        }

                        Location loc = new Location();
                        loc.x = Double.parseDouble(split[1]);
                        loc.y = Double.parseDouble(split[2]);
                        loc.z = Double.parseDouble(split[3]);
                        if (split.length == 6) {
                            loc.rotX = Float.parseFloat(split[4]);
                            loc.rotY = Float.parseFloat(split[5]);
                        }
                        warps.put(split[0].toLowerCase(), loc);
                    }
                    scanner.close();
                } catch (Exception e) {
                    log.log(Level.SEVERE, "Exception while reading " + location, e);
                }
            }
        }
    }

    public void loadItems() {
        String location = etc.getInstance().itemLoc;

        if (!(new File(location).exists())) {
            FileWriter writer = null;
            try {
                writer = new FileWriter(location);
                writer.write("#Add your items in here (When adding your entry DO NOT include #!)\r\n");
                writer.write("#The format is:\r\n");
                writer.write("#NAME:ID\r\n");
                writer.write("#Default Items:\r\n");
                writer.write("air:0\r\n");
                writer.write("rock:1\r\n");
                writer.write("grass:2\r\n");
                writer.write("dirt:3\r\n");
                writer.write("cobblestone:4\r\n");
                writer.write("wood:5\r\n");
                writer.write("sapling:6\r\n");
                writer.write("adminium:7\r\n");
                writer.write("water:8\r\n");
                writer.write("stillwater:9\r\n");
                writer.write("lava:10\r\n");
                writer.write("stilllava:11\r\n");
                writer.write("sand:12\r\n");
                writer.write("gravel:13\r\n");
                writer.write("goldore:14\r\n");
                writer.write("ironore:15\r\n");
                writer.write("coalore:16\r\n");
                writer.write("tree:17\r\n");
                writer.write("leaves:18\r\n");
                writer.write("sponge:19\r\n");
                writer.write("glass:20\r\n");
                writer.write("cloth:35\r\n");
                writer.write("flower:37\r\n");
                writer.write("rose:38\r\n");
                writer.write("brownmushroom:39\r\n");
                writer.write("redmushroom:40\r\n");
                writer.write("gold:41\r\n");
                writer.write("iron:42\r\n");
                writer.write("doublestair:43\r\n");
                writer.write("stair:44\r\n");
                writer.write("brick:45\r\n");
                writer.write("tnt:46\r\n");
                writer.write("bookshelf:47\r\n");
                writer.write("mossycobblestone:48\r\n");
                writer.write("obsidian:49\r\n");
                writer.write("torch:50\r\n");
                writer.write("fire:51\r\n");
                writer.write("mobspawner:52\r\n");
                writer.write("woodstairs:53\r\n");
                writer.write("chest:54\r\n");
                writer.write("redstonedust:55\r\n");
                writer.write("diamondore:56\r\n");
                writer.write("diamondblock:57\r\n");
                writer.write("workbench:58\r\n");
                writer.write("crop:59\r\n");
                writer.write("soil:60\r\n");
                writer.write("furnace:61\r\n");
                writer.write("litfurnace:62\r\n");
                writer.write("signblock:63\r\n");
                writer.write("wooddoorblock:64\r\n");
                writer.write("ladder:65\r\n");
                writer.write("rails:66\r\n");
                writer.write("cobblestonestairs:67\r\n");
                writer.write("signblocktop:68\r\n");
                writer.write("lever:69\r\n");
                writer.write("rockplate:70\r\n");
                writer.write("irondoorblock:71\r\n");
                writer.write("woodplate:72\r\n");
                writer.write("redstoneore:73\r\n");
                writer.write("redstoneorealt:74\r\n");
                writer.write("redstonetorchoff:75\r\n");
                writer.write("redstonetorchon:76\r\n");
                writer.write("button:77\r\n");
                writer.write("snow:78\r\n");
                writer.write("ice:79\r\n");
                writer.write("snowblock:80\r\n");
                writer.write("cactus:81\r\n");
                writer.write("clayblock:82\r\n");
                writer.write("reedblock:83\r\n");
                writer.write("jukebox:84\r\n");
                writer.write("fence:85\r\n");
                writer.write("ironshovel:256\r\n");
                writer.write("ironpickaxe:257\r\n");
                writer.write("ironaxe:258\r\n");
                writer.write("flintandsteel:259\r\n");
                writer.write("apple:260\r\n");
                writer.write("bow:261\r\n");
                writer.write("arrow:262\r\n");
                writer.write("coal:263\r\n");
                writer.write("diamond:264\r\n");
                writer.write("ironbar:265\r\n");
                writer.write("goldbar:266\r\n");
                writer.write("ironsword:267\r\n");
                writer.write("woodsword:268\r\n");
                writer.write("woodshovel:269\r\n");
                writer.write("woodpickaxe:270\r\n");
                writer.write("woodaxe:271\r\n");
                writer.write("stonesword:272\r\n");
                writer.write("stoneshovel:273\r\n");
                writer.write("stonepickaxe:274\r\n");
                writer.write("stoneaxe:275\r\n");
                writer.write("diamondsword:276\r\n");
                writer.write("diamondshovel:277\r\n");
                writer.write("diamondpickaxe:278\r\n");
                writer.write("diamondaxe:279\r\n");
                writer.write("stick:280\r\n");
                writer.write("bowl:281\r\n");
                writer.write("bowlwithsoup:282\r\n");
                writer.write("goldsword:283\r\n");
                writer.write("goldshovel:284\r\n");
                writer.write("goldpickaxe:285\r\n");
                writer.write("goldaxe:286\r\n");
                writer.write("string:287\r\n");
                writer.write("feather:288\r\n");
                writer.write("gunpowder:289\r\n");
                writer.write("woodhoe:290\r\n");
                writer.write("stonehoe:291\r\n");
                writer.write("ironhoe:292\r\n");
                writer.write("diamondhoe:293\r\n");
                writer.write("goldhoe:294\r\n");
                writer.write("seeds:295\r\n");
                writer.write("wheat:296\r\n");
                writer.write("bread:297\r\n");
                writer.write("leatherhelmet:298\r\n");
                writer.write("leatherchestplate:299\r\n");
                writer.write("leatherpants:300\r\n");
                writer.write("leatherboots:301\r\n");
                writer.write("chainmailhelmet:302\r\n");
                writer.write("chainmailchestplate:303\r\n");
                writer.write("chainmailpants:304\r\n");
                writer.write("chainmailboots:305\r\n");
                writer.write("ironhelmet:306\r\n");
                writer.write("ironchestplate:307\r\n");
                writer.write("ironpants:308\r\n");
                writer.write("ironboots:309\r\n");
                writer.write("diamondhelmet:310\r\n");
                writer.write("diamondchestplate:311\r\n");
                writer.write("diamondpants:312\r\n");
                writer.write("diamondboots:313\r\n");
                writer.write("goldhelmet:314\r\n");
                writer.write("goldchestplate:315\r\n");
                writer.write("goldpants:316\r\n");
                writer.write("goldboots:317\r\n");
                writer.write("flint:318\r\n");
                writer.write("meat:319\r\n");
                writer.write("cookedmeat:320\r\n");
                writer.write("painting:321\r\n");
                writer.write("goldenapple:322\r\n");
                writer.write("sign:323\r\n");
                writer.write("wooddoor:324\r\n");
                writer.write("bucket:325\r\n");
                writer.write("waterbucket:326\r\n");
                writer.write("lavabucket:327\r\n");
                writer.write("minecart:328\r\n");
                writer.write("saddle:329\r\n");
                writer.write("irondoor:330\r\n");
                writer.write("redstonedust:331\r\n");
                writer.write("snowball:332\r\n");
                writer.write("boat:333\r\n");
                writer.write("leather:334\r\n");
                writer.write("milkbucket:335\r\n");
                writer.write("brick:336\r\n");
                writer.write("clay:337\r\n");
                writer.write("reed:338\r\n");
                writer.write("paper:339\r\n");
                writer.write("book:340\r\n");
                writer.write("slimeorb:341\r\n");
                writer.write("storageminecart:342\r\n");
                writer.write("poweredminecart:343\r\n");
                writer.write("egg:344\r\n");
            } catch (Exception e) {
                log.log(Level.SEVERE, "Exception while creating " + location, e);
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        log.log(Level.SEVERE, "Exception while closing writer for " + location, e);
                    }
                }
            }
        }

        // This, for sure, now exists.
        synchronized (itemLock) {
            items = new HashMap<String, Integer>();
            try {
                Scanner scanner = new Scanner(new File(location));
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.startsWith("#")) {
                        continue;
                    }
                    if (line.equals("")) {
                        continue;
                    }
                    String[] split = line.split(":");
                    String name = split[0];

                    this.items.put(name, Integer.parseInt(split[1]));
                }
                scanner.close();
            } catch (Exception e) {
                log.log(Level.SEVERE, "Exception while reading " + location + " (Are you sure you formatted it correctly?)", e);
            }
        }
    }

    //Users
    public void addUser(User user) {
        String usersLoc = etc.getInstance().usersLoc;

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(usersLoc, true));
            StringBuilder builder = new StringBuilder();
            //#NAME:GROUPS:ADMIN/UNRESTRICTED:COLOR:COMMANDS
            builder.append(user.Name);
            builder.append(":");
            builder.append(ia.combineSplit(0, user.Groups, ","));
            builder.append(":");
            if (user.Administrator) {
                builder.append("2");
            } else if (user.IgnoreRestrictions) {
                builder.append("1");
            } else if (!user.CanModifyWorld) {
                builder.append("-1");
            } else {
                builder.append("0");
            }
            builder.append(":");
            builder.append(user.Prefix);
            builder.append(":");
            builder.append(ia.combineSplit(0, user.Commands, ","));
            bw.append(builder.toString());
            bw.newLine();
            bw.close();
            synchronized (userLock) {
                users.add(user);
            }
        } catch (Exception ex) {
            log.log(Level.SEVERE, "Exception while writing new user to " + usersLoc, ex);
        }
    }

    public void modifyUser(User user) {
        String usersLoc = etc.getInstance().usersLoc;

        try {
            // Now to save...
            BufferedReader reader = new BufferedReader(new FileReader(new File(usersLoc)));
            StringBuilder toWrite = new StringBuilder();
            String line = "";
            while ((line = reader.readLine()) != null) {
                if (!line.contains(user.Name)) {
                    toWrite.append(line).append("\r\n");
                } else {
                    StringBuilder builder = new StringBuilder();
                    builder.append(user.Name);
                    builder.append(":");
                    builder.append(ia.combineSplit(0, user.Groups, ","));
                    builder.append(":");
                    if (user.Administrator) {
                        builder.append("2");
                    } else if (user.IgnoreRestrictions) {
                        builder.append("1");
                    } else if (!user.CanModifyWorld) {
                        builder.append("-1");
                    } else {
                        builder.append("0");
                    }
                    builder.append(":");
                    builder.append(user.Prefix);
                    builder.append(":");
                    builder.append(ia.combineSplit(0, user.Commands, ","));
                    toWrite.append(builder.toString()).append("\r\n");
                }
            }
            reader.close();

            FileWriter writer = new FileWriter(usersLoc);
            writer.write(toWrite.toString());
            writer.close();

            synchronized (userLock) {
                users.add(user);
            }
        } catch (Exception ex) {
            log.log(Level.SEVERE, "Exception while editing user in " + usersLoc, ex);
        }
    }

    //Groups
    public void addGroup(Group group) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void modifyGroup(Group group) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Kits
    public void addKit(Kit kit) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void modifyKit(Kit kit) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Homes
    public void addHome(String name, Location location) {
        String homeLoc = etc.getInstance().homeLoc;
        try {
            if (etc.getInstance().saveHomes) {
                BufferedWriter bw = new BufferedWriter(new FileWriter(homeLoc, true));
                StringBuilder builder = new StringBuilder();
                builder.append(name);
                builder.append(":");
                builder.append(location.x);
                builder.append(":");
                builder.append(location.y);
                builder.append(":");
                builder.append(location.z);
                builder.append(":");
                builder.append(location.rotX);
                builder.append(":");
                builder.append(location.rotY);
                bw.append(builder.toString());
                bw.newLine();
                bw.close();
            }
            synchronized (homes) {
                homes.put(name, location);
            }
        } catch (Exception e2) {
            log.log(Level.SEVERE, "Exception while writing new user home to " + homeLoc, e2);
        }
    }

    public void changeHome(String name, Location location) {
        synchronized (homes) {
            homes.put(name, location);
        }
        FileWriter writer = null;
        String homeLoc = etc.getInstance().homeLoc;
        try {
            // Now to save...
            if (etc.getInstance().saveHomes) {
                BufferedReader reader = new BufferedReader(new FileReader(new File(homeLoc)));
                StringBuilder toWrite = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    if (!line.contains(name)) {
                        toWrite.append(line).append("\r\n");
                    } else {
                        StringBuilder builder = new StringBuilder();
                        builder.append(name);
                        builder.append(":");
                        builder.append(location.x);
                        builder.append(":");
                        builder.append(location.y);
                        builder.append(":");
                        builder.append(location.z);
                        builder.append(":");
                        builder.append(location.rotX);
                        builder.append(":");
                        builder.append(location.rotY);
                        toWrite.append(builder.toString()).append("\r\n");
                    }
                }
                reader.close();

                writer = new FileWriter(homeLoc);
                writer.write(toWrite.toString());
                writer.close();
            }
        } catch (Exception e1) {
            log.log(Level.SEVERE, "Exception while editing user home in " + homeLoc, e1);
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException ex) {
            }
        }
    }

    //Warps
    public void addWarp(String name, Location location) {
        BufferedWriter bw = null;
        String warpLoc = etc.getInstance().warpLoc;
        try {
            bw = new BufferedWriter(new FileWriter(warpLoc, true));
            StringBuilder builder = new StringBuilder();
            builder.append(name.toLowerCase());
            builder.append(":");
            builder.append(location.x);
            builder.append(":");
            builder.append(location.y);
            builder.append(":");
            builder.append(location.z);
            builder.append(":");
            builder.append(location.rotX);
            builder.append(":");
            builder.append(location.rotY);
            bw.append(builder.toString());
            bw.newLine();
            synchronized (warps) {
                warps.put(name, location);
            }
        } catch (Exception e2) {
            log.log(Level.SEVERE, "Exception while writing new warp to " + warpLoc, e2);
        } finally {
            try {
                if (bw != null) {
                    bw.close();
                }
            } catch (IOException ex) {
            }
        }
    }

    public void changeWarp(String name, Location location) {
        synchronized (warps) {
            warps.put(name, location);
        }
        FileWriter writer = null;
        String warpLoc = etc.getInstance().warpLoc;

        try {
            // Now to save...
            BufferedReader reader = new BufferedReader(new FileReader(new File(warpLoc)));
            String line = "";
            StringBuilder toSave = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                if (!line.contains(name.toLowerCase())) {
                    toSave.append(line).append("\r\n");
                } else {
                    StringBuilder builder = new StringBuilder();
                    builder.append(name.toLowerCase());
                    builder.append(":");
                    builder.append(location.x);
                    builder.append(":");
                    builder.append(location.y);
                    builder.append(":");
                    builder.append(location.z);
                    builder.append(":");
                    builder.append(location.rotX);
                    builder.append(":");
                    builder.append(location.rotY);
                    toSave.append(builder.toString()).append("\r\n");
                }
            }
            reader.close();

            writer = new FileWriter(warpLoc);
            writer.write(toSave.toString());
        } catch (Exception e1) {
            log.log(Level.SEVERE, "Exception while editing warp in " + warpLoc, e1);
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException ex) {
            }
        }
    }
}
