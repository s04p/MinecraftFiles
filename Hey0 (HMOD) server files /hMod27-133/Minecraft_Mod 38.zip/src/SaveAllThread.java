/* Save-alls every x minutes according to settings */

import net.minecraft.server.MinecraftServer;

public class SaveAllThread implements Runnable {
    private boolean running = false;
    private MinecraftServer server;

    public SaveAllThread(MinecraftServer paramMinecraftServer) {
        this.server = paramMinecraftServer;
    }

    public void run() {
        while (this.running) {
            try {
                Thread.sleep(etc.getInstance().saveInterval);
            } catch (InterruptedException localInterruptedException) {
            }
            server.a("save-all", server);
        }
    }

    public void start() {
        this.running = true;
        new Thread(this).start();
    }

    public void stop() {
        this.running = false;
    }
}
