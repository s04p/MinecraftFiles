INSERT INTO `items` (`name`, `itemid`) VALUES 
('lapislazuliore', 21), 
('lapislazuliblock', 22), 
('dispenser', 23), 
('sandstone', 24), 
('noteblock', 25), 
('cakeblock', 92),
('cookedfish',350)
('inksack', 351), 
('dye', 351), 
('bone', 352), 
('sugar', 353), 
('cake', 354);