/**
 *
 * @author 
 */
public class HumanEntity extends LivingEntity {
    fy human;

    /**
     *
     */
    public HumanEntity() {
    }

    /**
     *
     * @param human
     */
    public HumanEntity(fy human) {
        super((jz) human);
        this.human = human;
    }
}
