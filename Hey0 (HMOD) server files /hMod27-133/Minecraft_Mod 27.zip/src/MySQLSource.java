
import net.minecraft.server.MinecraftServer;

/* MySQL Data Source */
public class MySQLSource extends DataSource {

    public void initialize(MinecraftServer server) {
        loadUsers();
        loadGroups();
        loadKits();
        loadHomes();
        loadWarps();
    }

    public void loadUsers() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void loadGroups() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void loadKits() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void loadHomes() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void loadWarps() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Users
    public void addUser(User user) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void modifyUser(User user) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Groups
    public void addGroup(Group group) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void modifyGroup(Group group) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Kits
    public void addKit(Kit kit) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void modifyKit(Kit kit) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Homes
    public void addHome(String name, Location location) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void changeHome(String name, Location location) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Warps
    public void addWarp(String name, Location location) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void changeWarp(String name, Location location) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
