/* Flat file data source */
public class FlatFileSource {

}
