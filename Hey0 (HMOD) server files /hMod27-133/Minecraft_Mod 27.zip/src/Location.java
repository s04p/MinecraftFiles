/* Class used to store a location */
public class Location {

    public double x;
    public double z;
    public double y;
    public float rotX;
    public float rotY;
}
