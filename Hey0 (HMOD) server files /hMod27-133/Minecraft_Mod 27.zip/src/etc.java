/* Just a general storage for all my crap */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.minecraft.server.*;

public class etc {

    private static final Logger a = Logger.getLogger("Minecraft");
    private static volatile etc instance;
    private static MinecraftServer server;
    private ArrayList<String> muted = new ArrayList<String>();
    private Map<String, Location> homes = new HashMap<String, Location>();
    private Map<String, Location> warps = new HashMap<String, Location>();
    private Map<String, Integer> items = new HashMap<String, Integer>();
    private List<Kit> kits = new ArrayList<Kit>();
    private List<Group> groups = new ArrayList<Group>();
    private List<User> users = new ArrayList<User>();
    private String[] reserveSlots = null;
    public String usersLoc = "users.txt", kitsLoc = "kits.txt", homeLoc = "homes.txt", warpLoc = "warps.txt", itemLoc = "items.txt", groupLoc = "groups.txt", commandsLoc = "commands.txt";
    public String[] allowedItems = null;
    public String[] disallowedItems = null;
    public String[] itemSpawnBlacklist = null;
    public String[] motd = null;
    private String[] playerWhitelist = null;
    public boolean reserveSlotsEnabled = false;
    public boolean saveHomes = true;
    public boolean firstLoad = true;
    public int playerLimit = 20;
    public int spawnProtectionSize = 16;
    public long sleepTime = 30000;
    public long saveInterval = 1800000;
    public LinkedHashMap<String, String> commands = new LinkedHashMap<String, String>();
    private ReloadThread reloadThread;
    private SaveAllThread saveThread;

    private etc() {
        commands.put("/help", "[Page] - Shows a list of commands. 7 per page.");
        commands.put("/playerlist", "- Shows a list of players");
        commands.put("/reload", "- Reloads config");
        commands.put("/banip", "[Player] <Reason> - Bans the player's IP");
        commands.put("/unbanip", "[IP] - Unbans the IP");
        commands.put("/ban", "[Player] <Reason> - Bans the player");
        commands.put("/unban", "[Player] - Unbans the player");
        commands.put("/mute", "[Player] - Toggles mute on player.");
        commands.put("/tp", "[Player] - Teleports to player. Credits to Zet from SA");
        commands.put("/tphere", "[Player] - Teleports the player to you");
        commands.put("/kick", "[Player] <Reason> - Kicks player");
        commands.put("/item", "[ID] [Amount] <Player> - Gives items");
        commands.put("/kit", "[Kit] - Gives a kit. To get a list of kits type /kit");
        commands.put("/home", "- Teleports you home");
        commands.put("/sethome", "- Sets your home");
        commands.put("/setspawn", "- Sets the spawn point to your position.");
        commands.put("/me", "[Message] - * hey0 says hi!");
        commands.put("/msg", "[Player] [Message] - Sends a message to player");
        commands.put("/spawn", "- Teleports you to spawn");
        commands.put("/warp", "[Warp] - Warps to the specified warp.");
        commands.put("/setwarp", "[Warp] - Sets the warp to your current position.");
        commands.put("/getpos", "- Displays your current position.");
        commands.put("/compass", "- Gives you a compass reading.");
        commands.put("/time", "[Time|day|night] - Changes time");
        commands.put("/lighter", "- Gives you a lighter for lighting furnaces");
        commands.put("/motd", "- Displays the MOTD");

        load();
    }

    public final void load() {
        if (server.d == null) {
            server.d = new co(new File("server.properties"));
        } else {
            server.d.reload(new File("server.properties"));
        }

        try {
            allowedItems = server.d.getString("alloweditems", "").split(",");
            disallowedItems = server.d.getString("disalloweditems", "").split(",");
            itemSpawnBlacklist = server.d.getString("itemspawnblacklist", "").split(",");
            reserveSlots = server.d.getString("reserveslots", "").split(",");
            playerWhitelist = server.d.getString("playerwhitelist", "").split(",");
            motd = server.d.getString("motd", "Type /help for a list of commands.").split("@");
            playerLimit = server.d.getInt("max-players", 20);
            reserveSlotsEnabled = server.d.getBoolean("reserveslotsenabled", false);
            saveHomes = server.d.getBoolean("save-homes", true);
            usersLoc = server.d.getString("admintxtlocation", "users.txt");
            kitsLoc = server.d.getString("kitstxtlocation", "kits.txt");
            homeLoc = server.d.getString("homelocation", "homes.txt");
            warpLoc = server.d.getString("warplocation", "warps.txt");
            itemLoc = server.d.getString("itemstxtlocation", "items.txt");
            groupLoc = server.d.getString("group-txt-location", "groups.txt");
            spawnProtectionSize = server.d.getInt("spawn-protection-size", 16);
            sleepTime = server.d.getLong("reload-interval", 30000);
            saveInterval = server.d.getLong("save-interval", 1800000);
        } catch (Exception e) {
            a.log(Level.SEVERE, "Exception while reading from server.properties", e);
            // Just in case...
            disallowedItems = new String[]{""};
            allowedItems = new String[]{""};
            reserveSlots = new String[]{""};
            playerWhitelist = new String[]{""};
            itemSpawnBlacklist = new String[]{""};
            motd = new String[]{"Type /help for a list of commands."};
        }

        synchronized (users) {
            users = new ArrayList<User>();
            if (new File(usersLoc).exists()) {
                try {
                    Scanner scanner = new Scanner(new File(usersLoc));
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        if (line.startsWith("#") || line.equals("")) {
                            continue;
                        }

                        String[] split = line.split(":");

                        User user = new User();
                        user.Name = split[0];
                        user.Groups = split[1].split(",");

                        if (split.length >= 3) {
                            if (split[2].equals("1")) {
                                user.IgnoreRestrictions = true;
                            } else if (split[2].equals("2")) {
                                user.Administrator = true;
                            } else if (split[2].equals("-1")) {
                                user.CanModifyWorld = false;
                            }
                        }
                        if (split.length >= 4) {
                            user.Prefix = split[3].replace("\\u00A7", "§");
                        }
                        if (split.length >= 5) {
                            user.Commands = split[4].split(",");
                        } else {
                            user.Commands = new String[0];
                        }

                        users.add(user);
                    }
                    scanner.close();
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while reading " + usersLoc + " (Are you sure you formatted it correctly?)", e);
                }
            } else {
                FileWriter writer = null;
                try {
                    writer = new FileWriter(usersLoc);
                    writer.write("#Add your users here (When adding your entry DO NOT include #!)\r\n");
                    writer.write("#The format is:\r\n");
                    writer.write("#NAME:GROUPS:ADMIN/UNRESTRICTED:COLOR:COMMANDS\r\n");
                    writer.write("#For administrative powers set admin/unrestricted to 2.\r\n");
                    writer.write("#For no restrictions and ability to give out items set it to 1.\r\n");
                    writer.write("#If you don't want the person to be able to build set it to -1.\r\n");
                    writer.write("#Admin/unrestricted, color and commands are optional.\r\n");
                    writer.write("#Examples:\r\n");
                    writer.write("#Adminfoo:admins\r\n");
                    writer.write("#Moderator39:mods:1:§0:/unban\r\n");
                    writer.write("#BobTheBuilder:vip:0:§d\r\n");
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while creating " + usersLoc, e);
                } finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                    } catch (IOException e) {
                        a.log(Level.SEVERE, "Exception while closing writer for " + usersLoc, e);
                    }
                }
            }
        }

        synchronized (groups) {
            groups = new ArrayList<Group>();
            if (new File(groupLoc).exists()) {
                try {
                    Scanner scanner = new Scanner(new File(groupLoc));
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        if (line.startsWith("#") || line.equals("")) {
                            continue;
                        }

                        String[] split = line.split(":");
                        Group group = new Group();
                        group.Name = split[0];
                        group.Prefix = split[1].replace("\\u00A7", "§");
                        group.Commands = split[2].split(",");
                        if (split.length >= 4) {
                            group.InheritedGroups = split[3].split(",");
                        }
                        if (split.length >= 5) {
                            if (split[4].equals("1")) {
                                group.IgnoreRestrictions = true;
                            } else if (split[4].equals("2")) {
                                group.Administrator = true;
                            } else if (split[4].equals("-1")) {
                                group.CanModifyWorld = false;
                            }
                        }

                        // kind of a shitty way, but whatever.
                        if (group.InheritedGroups != null) {
                            if (group.InheritedGroups[0].equalsIgnoreCase(group.Name)) {
                                group.InheritedGroups = new String[1];
                                group.InheritedGroups[0] = "";
                                group.DefaultGroup = true;
                            }
                        }

                        groups.add(group);
                    }
                    scanner.close();
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while reading " + groupLoc + " (Are you sure you formatted it correctly?)", e);
                }
            } else {
                FileWriter writer = null;
                try {
                    writer = new FileWriter(groupLoc);
                    writer.write("#Add your groups here (When adding your entry DO NOT include #!)\r\n");
                    writer.write("#The format is:\r\n");
                    writer.write("#NAME:COLOR:COMMANDS:INHERITEDGROUPS:ADMIN/UNRESTRICTED\r\n");
                    writer.write("#For administrative powers set admin/unrestricted to 2.\r\n");
                    writer.write("#For no restrictions and ability to give out items set it to 1.\r\n");
                    writer.write("#If you don't want the group to be able to build set it to -1.\r\n");
                    writer.write("#Inherited groups and admin/unrestricted are optional.\r\n");
                    writer.write("#Examples:\r\n");
                    writer.write("admins:§c:*:mods:2\r\n");
                    writer.write("mods:§b:/ban,/kick,/item,/tp,/tphere,/s,/i,/give:vip:1\r\n");
                    writer.write("vip:§a::default\r\n");
                    writer.write("default:§f:/help,/sethome,/home,/spawn,/me,/msg,/kit,/playerlist,/warp,/motd,/compass,/tell,/m,/who:default\r\n");
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while creating " + groupLoc, e);
                } finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                    } catch (IOException e) {
                        a.log(Level.SEVERE, "Exception while closing writer for " + groupLoc, e);
                    }
                }
            }
        }

        synchronized (kits) {
            kits = new ArrayList<Kit>();
            if (new File(kitsLoc).exists()) {
                try {
                    Scanner scanner = new Scanner(new File(kitsLoc));
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        if (line.startsWith("#") || line.equals("")) // Skip it.
                        {
                            continue;
                        }
                        String[] split = line.split(":");
                        String name = split[0];
                        String[] ids = split[1].split(",");
                        int delay = Integer.parseInt(split[2]);
                        String group = "";
                        if (split.length == 4) {
                            group = split[3];
                        }
                        Kit kit = new Kit();
                        kit.Name = name;
                        kit.IDs = new HashMap<String, Integer>();
                        for (String str : ids) {
                            String id = "";
                            int amount = 1;
                            if (str.contains(" ")) {
                                id = str.split(" ")[0];
                                amount = Integer.parseInt(str.split(" ")[1]);
                            } else {
                                id = str;
                            }
                            kit.IDs.put(id, amount);
                        }
                        kit.Delay = delay;
                        kit.Group = group;
                        kits.add(kit);
                    }
                    scanner.close();
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while reading " + kitsLoc, e);
                }
            } else {
                FileWriter writer = null;
                try {
                    writer = new FileWriter(kitsLoc);
                    writer.write("#Add your kits here. Example entry below (When adding your entry DO NOT include #!)\r\n");
                    writer.write("#miningbasics:1,2,3,4:6000\r\n");
                    writer.write("#The formats are (Find out more about groups in " + usersLoc + ":\r\n");
                    writer.write("#NAME:IDs:DELAY\r\n");
                    writer.write("#NAME:IDs:DELAY:GROUP\r\n");
                    writer.write("#6000 for delay is roughly 5 minutes.\r\n");
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while creating " + kitsLoc, e);
                } finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                    } catch (IOException e) {
                    }
                }
            }
        }

        synchronized (homes) {
            homes = new HashMap<String, Location>();
            if (saveHomes) {
                if (new File(homeLoc).exists()) {
                    try {
                        Scanner scanner = new Scanner(new File(homeLoc));
                        while (scanner.hasNextLine()) {
                            String line = scanner.nextLine();
                            if (line.startsWith("#") || line.equals("")) {
                                continue;
                            }
                            String[] split = line.split(":");
                            if (split.length < 4) {
                                continue;
                            }
                            Location loc = new Location();
                            loc.x = Double.parseDouble(split[1]);
                            loc.y = Double.parseDouble(split[2]);
                            loc.z = Double.parseDouble(split[3]);
                            if (split.length == 6) {
                                loc.rotX = Float.parseFloat(split[4]);
                                loc.rotY = Float.parseFloat(split[5]);
                            }
                            homes.put(split[0], loc);
                        }
                        scanner.close();
                    } catch (Exception e) {
                        a.log(Level.SEVERE, "Exception while reading " + homeLoc, e);
                    }
                }
            }
        }

        synchronized (warps) {
            warps = new HashMap<String, Location>();
            if (new File(warpLoc).exists()) {
                try {
                    Scanner scanner = new Scanner(new File(warpLoc));
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        if (line.startsWith("#") || line.equals("")) {
                            continue;
                        }
                        String[] split = line.split(":");
                        if (split.length < 4) {
                            continue;
                        }

                        Location loc = new Location();
                        loc.x = Double.parseDouble(split[1]);
                        loc.y = Double.parseDouble(split[2]);
                        loc.z = Double.parseDouble(split[3]);
                        if (split.length == 6) {
                            loc.rotX = Float.parseFloat(split[4]);
                            loc.rotY = Float.parseFloat(split[5]);
                        }
                        warps.put(split[0].toLowerCase(), loc);
                    }
                    scanner.close();
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while reading " + warpLoc, e);
                }
            }
        }

        synchronized (items) {
            items = new HashMap<String, Integer>();
            if (!(new File(this.itemLoc).exists())) {
                FileWriter writer = null;
                try {
                    writer = new FileWriter(this.itemLoc);
                    writer.write("#Add your items in here (When adding your entry DO NOT include #!)\r\n");
                    writer.write("#The format is:\r\n");
                    writer.write("#NAME:ID\r\n");
                    writer.write("#Default Items:\r\n");
                    writer.write("air:0\r\n");
                    writer.write("rock:1\r\n");
                    writer.write("grass:2\r\n");
                    writer.write("dirt:3\r\n");
                    writer.write("cobblestone:4\r\n");
                    writer.write("wood:5\r\n");
                    writer.write("sapling:6\r\n");
                    writer.write("adminium:7\r\n");
                    writer.write("water:8\r\n");
                    writer.write("stillwater:9\r\n");
                    writer.write("lava:10\r\n");
                    writer.write("stilllava:11\r\n");
                    writer.write("sand:12\r\n");
                    writer.write("gravel:13\r\n");
                    writer.write("goldore:14\r\n");
                    writer.write("ironore:15\r\n");
                    writer.write("coalore:16\r\n");
                    writer.write("tree:17\r\n");
                    writer.write("leaves:18\r\n");
                    writer.write("sponge:19\r\n");
                    writer.write("glass:20\r\n");
                    writer.write("cloth:35\r\n");
                    writer.write("flower:37\r\n");
                    writer.write("rose:38\r\n");
                    writer.write("brownmushroom:39\r\n");
                    writer.write("redmushroom:40\r\n");
                    writer.write("gold:41\r\n");
                    writer.write("iron:42\r\n");
                    writer.write("doublestair:43\r\n");
                    writer.write("stair:44\r\n");
                    writer.write("brick:45\r\n");
                    writer.write("tnt:46\r\n");
                    writer.write("bookshelf:47\r\n");
                    writer.write("mossycobblestone:48\r\n");
                    writer.write("obsidian:49\r\n");
                    writer.write("torch:50\r\n");
                    writer.write("fire:51\r\n");
                    writer.write("mobspawner:52\r\n");
                    writer.write("woodstairs:53\r\n");
                    writer.write("chest:54\r\n");
                    writer.write("redstonedust:55\r\n");
                    writer.write("diamondore:56\r\n");
                    writer.write("diamondblock:57\r\n");
                    writer.write("workbench:58\r\n");
                    writer.write("crop:59\r\n");
                    writer.write("soil:60\r\n");
                    writer.write("furnace:61\r\n");
                    writer.write("litfurnace:62\r\n");
                    writer.write("signblock:63\r\n");
                    writer.write("wooddoorblock:64\r\n");
                    writer.write("ladder:65\r\n");
                    writer.write("rails:66\r\n");
                    writer.write("cobblestonestairs:67\r\n");
                    writer.write("signblocktop:68\r\n");
                    writer.write("lever:69\r\n");
                    writer.write("rockplate:70\r\n");
                    writer.write("irondoorblock:71\r\n");
                    writer.write("woodplate:72\r\n");
                    writer.write("redstoneore:73\r\n");
                    writer.write("redstoneorealt:74\r\n");
                    writer.write("redstonetorchoff:75\r\n");
                    writer.write("redstonetorchon:76\r\n");
                    writer.write("button:77\r\n");
                    writer.write("snow:78\r\n");
                    writer.write("ice:79\r\n");
                    writer.write("snowblock:80\r\n");
                    writer.write("cactus:81\r\n");
                    writer.write("clayblock:82\r\n");
                    writer.write("reedblock:83\r\n");
                    writer.write("jukebox:84\r\n");
                    writer.write("fence:85\r\n");
                    writer.write("ironshovel:256\r\n");
                    writer.write("ironpickaxe:257\r\n");
                    writer.write("ironaxe:258\r\n");
                    writer.write("flintandsteel:259\r\n");
                    writer.write("apple:260\r\n");
                    writer.write("bow:261\r\n");
                    writer.write("arrow:262\r\n");
                    writer.write("coal:263\r\n");
                    writer.write("diamond:264\r\n");
                    writer.write("ironbar:265\r\n");
                    writer.write("goldbar:266\r\n");
                    writer.write("ironsword:267\r\n");
                    writer.write("woodsword:268\r\n");
                    writer.write("woodshovel:269\r\n");
                    writer.write("woodpickaxe:270\r\n");
                    writer.write("woodaxe:271\r\n");
                    writer.write("stonesword:272\r\n");
                    writer.write("stoneshovel:273\r\n");
                    writer.write("stonepickaxe:274\r\n");
                    writer.write("stoneaxe:275\r\n");
                    writer.write("diamondsword:276\r\n");
                    writer.write("diamondshovel:277\r\n");
                    writer.write("diamondpickaxe:278\r\n");
                    writer.write("diamondaxe:279\r\n");
                    writer.write("stick:280\r\n");
                    writer.write("bowl:281\r\n");
                    writer.write("bowlwithsoup:282\r\n");
                    writer.write("goldsword:283\r\n");
                    writer.write("goldshovel:284\r\n");
                    writer.write("goldpickaxe:285\r\n");
                    writer.write("goldaxe:286\r\n");
                    writer.write("string:287\r\n");
                    writer.write("feather:288\r\n");
                    writer.write("gunpowder:289\r\n");
                    writer.write("woodhoe:290\r\n");
                    writer.write("stonehoe:291\r\n");
                    writer.write("ironhoe:292\r\n");
                    writer.write("diamondhoe:293\r\n");
                    writer.write("goldhoe:294\r\n");
                    writer.write("seeds:295\r\n");
                    writer.write("wheat:296\r\n");
                    writer.write("bread:297\r\n");
                    writer.write("leatherhelmet:298\r\n");
                    writer.write("leatherchestplate:299\r\n");
                    writer.write("leatherpants:300\r\n");
                    writer.write("leatherboots:301\r\n");
                    writer.write("chainmailhelmet:302\r\n");
                    writer.write("chainmailchestplate:303\r\n");
                    writer.write("chainmailpants:304\r\n");
                    writer.write("chainmailboots:305\r\n");
                    writer.write("ironhelmet:306\r\n");
                    writer.write("ironchestplate:307\r\n");
                    writer.write("ironpants:308\r\n");
                    writer.write("ironboots:309\r\n");
                    writer.write("diamondhelmet:310\r\n");
                    writer.write("diamondchestplate:311\r\n");
                    writer.write("diamondpants:312\r\n");
                    writer.write("diamondboots:313\r\n");
                    writer.write("goldhelmet:314\r\n");
                    writer.write("goldchestplate:315\r\n");
                    writer.write("goldpants:316\r\n");
                    writer.write("goldboots:317\r\n");
                    writer.write("flint:318\r\n");
                    writer.write("meat:319\r\n");
                    writer.write("cookedmeat:320\r\n");
                    writer.write("painting:321\r\n");
                    writer.write("goldenapple:322\r\n");
                    writer.write("sign:323\r\n");
                    writer.write("wooddoor:324\r\n");
                    writer.write("bucket:325\r\n");
                    writer.write("waterbucket:326\r\n");
                    writer.write("lavabucket:327\r\n");
                    writer.write("minecart:328\r\n");
                    writer.write("saddle:329\r\n");
                    writer.write("irondoor:330\r\n");
                    writer.write("redstonedust:331\r\n");
                    writer.write("snowball:332\r\n");
                    writer.write("boat:333\r\n");
                    writer.write("leather:334\r\n");
                    writer.write("milkbucket:335\r\n");
                    writer.write("brick:336\r\n");
                    writer.write("clay:337\r\n");
                    writer.write("reed:338\r\n");
                    writer.write("paper:339\r\n");
                    writer.write("book:340\r\n");
                    writer.write("slimeorb:341\r\n");
                    writer.write("storageminecart:342\r\n");
                    writer.write("poweredminecart:343\r\n");
                    writer.write("egg:344\r\n");
                } catch (Exception e) {
                    a.log(Level.SEVERE, "Exception while creating " + this.itemLoc, e);
                } finally {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e) {
                            a.log(Level.SEVERE, "Exception while closing writer for " + this.itemLoc, e);
                        }
                    }
                }
            }

            // This, for sure, now exists.
            try {
                Scanner scanner = new Scanner(new File(this.itemLoc));
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.startsWith("#")) {
                        continue;
                    }
                    if (line.equals("")) {
                        continue;
                    }
                    String[] split = line.split(":");
                    String name = split[0];

                    this.items.put(name, Integer.parseInt(split[1]));
                }
                scanner.close();
            } catch (Exception e) {
                a.log(Level.SEVERE, "Exception while reading " + this.itemLoc + " (Are you sure you formatted it correctly?)", e);
            }
        }

        if (firstLoad) {
            firstLoad = false;
            load(); //too lazy to actually fix things. oh well.
        }
    }

    public static void setServer(MinecraftServer svr) {
        server = svr;
    }

    public static MinecraftServer getServer() {
        return server;
    }

    public static etc getInstance() {
        if (instance == null) {
            instance = new etc();
        }

        return instance;
    }

    public void startThreads() {
        if (saveInterval > 0 && saveThread == null) {
            saveThread = new SaveAllThread();
            saveThread.start();
        }

        if (sleepTime > 0 && reloadThread == null) {
            reloadThread = new ReloadThread();
            reloadThread.start();
        }
    }

    public boolean isOnReserve(String name) {
        for (String str : reserveSlots) {
            if (str.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public boolean isUserInGroup(dy e, String group) {
        return isUserInGroup(e.ap, group);
    }

    public boolean isUserInGroup(String name, String group) {
        if (group != null) {
            if (getDefaultGroup() != null) {
                if (group.equalsIgnoreCase(getDefaultGroup().Name)) {
                    return true;
                }
            } else {
                a.info("There's no default group.");
            }
        }
        User user = getUser(name);
        if (user != null) {
            for (String str : user.Groups) {
                if (recursiveUserInGroup(getGroup(str), group)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean recursiveUserInGroup(Group g, String group) {
        if (g == null || group == null) {
            return false;
        }

        if (g.Name.equalsIgnoreCase(group)) {
            return true;
        }
        if (g.InheritedGroups != null) {
            for (String str : g.InheritedGroups) {
                if (g.Name.equalsIgnoreCase(str)) {
                    return true;
                }
                Group g2 = getGroup(str);
                if (g2 != null) {
                    if (recursiveUserInGroup(g2, group)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public User getUser(String name) {
        synchronized (users) {
            for (User user : users) {
                if (user.Name.equalsIgnoreCase(name)) {
                    return user;
                }
            }
        }
        return null;
    }

    public Group getDefaultGroup() {
        synchronized (groups) {
            for (Group g : groups) {
                if (g.DefaultGroup) {
                    return g;
                }
            }
        }
        return null;
    }

    public String getUserColor(String name) {
        User user = getUser(name);
        if (user != null) {
            if (user.Prefix != null) {
                if (!user.Prefix.equals("")) {
                    return user.Prefix;
                }
            }
            Group group = getGroup(user.Groups[0]);
            if (group != null) {
                return group.Prefix;
            }
        }
        Group def = getDefaultGroup();
        return def != null ? def.Prefix : "";
    }

    public boolean canUseCommand(String name, String command) {
        User user = getUser(name);
        //holy motherfuck
        if (user != null) {
            for (String str : user.Commands) {
                if (str.equalsIgnoreCase(command)) {
                    return true;
                }
            }

            for (String str : user.Groups) {
                Group g = getGroup(str);
                if (g != null) {
                    if (recursiveUseCommand(g, command)) {
                        return true;
                    }
                }
            }
        }

        Group def = getDefaultGroup();
        if (def != null) {
            if (recursiveUseCommand(def, command)) {
                return true;
            }
        } else {
            a.info("No default group.");
        }

        return false;
    }

    private boolean recursiveUseCommand(Group g, String command) {
        for (String str : g.Commands) {
            if (str.equalsIgnoreCase(command) || str.equals("*")) {
                return true;
            }
        }

        if (g.InheritedGroups != null) {
            for (String str : g.InheritedGroups) {
                Group g2 = getGroup(str);
                if (g2 != null) {
                    if (recursiveUseCommand(g2, command)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public Group getGroup(String name) {
        synchronized (groups) {
            for (Group g : groups) {
                if (g.Name.equalsIgnoreCase(name)) {
                    return g;
                }
            }
        }

        if (!name.equals("")) {
            a.log(Level.INFO, "Unable to find group '{0}'. Are you sure you have that group in {1}?", new Object[]{name, groupLoc});
        }
        return null;
    }

    /*
    public void changeGroup(dy e, int group) {
    int user = -1;
    try {
    user = users.get(e.ap);
    } catch (Exception e1) {
    }

    if (user != -1) {
    try {
    user = users.get(e.ap);
    // Now to save...
    BufferedReader reader = new BufferedReader(new FileReader(new File(usersLoc)));
    String line = "", text = "";
    while ((line = reader.readLine()) != null) {
    if (!line.contains(e.ap))
    text += line + "\r\n";
    else {
    StringBuilder builder = new StringBuilder();
    builder.append(e.ap);
    builder.append(":");
    builder.append(group);
    text += builder.toString() + "\r\n";
    }
    }
    reader.close();

    FileWriter writer = new FileWriter(usersLoc);
    writer.write(text);
    writer.close();
    } catch (Exception e1) {
    a.log(Level.SEVERE, "Exception while editing user in " + usersLoc, e);
    }
    } else {
    // User doesn't exist, woo.
    try {
    BufferedWriter bw = new BufferedWriter(new FileWriter(usersLoc, true));
    StringBuilder builder = new StringBuilder();
    builder.append(e.ap);
    builder.append(":");
    builder.append(group);
    bw.newLine();
    bw.append(builder.toString());
    bw.close();
    users.put(e.ap, user);
    } catch (Exception e2) {
    a.log(Level.SEVERE, "Exception while writing new user to " + usersLoc, e);
    }
    }
    }*/
    public boolean hasKits() {
        return kits.size() > 0;
    }

    public String getKitNames(dy e) {
        StringBuilder builder = new StringBuilder();
        builder.append(""); //incaseofnull

        synchronized (kits) {
            for (Kit kit : kits) {
                if (isUserInGroup(e, kit.Group) || kit.Group.equals("")) {
                    builder.append(kit.Name).append(" ");
                }
            }
        }

        return builder.toString();
    }

    public Kit getKit(String name) {
        synchronized (kits) {
            for (Kit kit : kits) {
                if (kit.Name.equalsIgnoreCase(name)) {
                    return kit;
                }
            }
        }
        return null;
    }

    public boolean isAdmin(dy player) {
        return isAdmin(player.ap);
    }

    public boolean isAdmin(String player) {
        User user = getUser(player);
        if (user == null) {
            return false;
        }
        if (user.Administrator) {
            return true;
        }

        for (String str : user.Groups) {
            Group group = getGroup(str);
            if (group != null) {
                if (group.Administrator) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean canIgnoreRestrictions(dy player) {
        return canIgnoreRestrictions(player.ap);

    }

    public boolean canIgnoreRestrictions(String player) {
        User user = getUser(player);
        if (user == null) {
            return false;
        }
        if (user.Administrator || user.IgnoreRestrictions) {
            return true;
        }

        for (String str : user.Groups) {
            Group group = getGroup(str);
            if (group != null) {
                if (group.Administrator || group.IgnoreRestrictions) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean canBuild(dy player) {
        User user = getUser(player.ap);

        if (user == null) {
            return getDefaultGroup().CanModifyWorld;
        }

        if (!user.CanModifyWorld) {
            return false;
        }

        for (String str : user.Groups) {
            Group group = getGroup(str);
            if (group != null) {
                if (!group.CanModifyWorld) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean isMuted(dy e) {
        return muted.contains(e.ap);
    }

    public boolean toggleMute(dy e) {
        if (muted.contains(e.ap)) {
            muted.remove(e.ap);
        } else {
            muted.add(e.ap);
        }
        return muted.contains(e.ap);
    }

    public boolean isOnWhitelist(dy e) {
        return isOnWhitelist(e.ap);
    }

    public boolean isOnWhitelist(String user) {
        for (String str : playerWhitelist) {
            if (str.equalsIgnoreCase(user)) {
                return true;
            }
        }
        return false;
    }

    public boolean hasWhitelist() {
        return playerWhitelist.length > 0 && !playerWhitelist[0].equals("");
    }

    public Location getHome(String name) {
        synchronized (homes) {
            if (homes.containsKey(name)) {
                return homes.get(name.toLowerCase());
            }
        }
        return null;
    }

    public Location getWarp(String warpname) {
        synchronized (warps) {
            if (warps.containsKey(warpname)) {
                return warps.get(warpname.toLowerCase());
            }
        }
        return null;
    }

    public void changeHome(String name, Location loc) {
        if (homes.containsKey(name)) {
            synchronized (homes) {
                homes.put(name, loc);
            }
            FileWriter writer = null;
            try {
                // Now to save...
                if (saveHomes) {
                    BufferedReader reader = new BufferedReader(new FileReader(new File(homeLoc)));
                    StringBuilder toWrite = new StringBuilder();
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        if (!line.contains(name)) {
                            toWrite.append(line).append("\r\n");
                        } else {
                            StringBuilder builder = new StringBuilder();
                            builder.append(name);
                            builder.append(":");
                            builder.append(loc.x);
                            builder.append(":");
                            builder.append(loc.y);
                            builder.append(":");
                            builder.append(loc.z);
                            builder.append(":");
                            builder.append(loc.rotX);
                            builder.append(":");
                            builder.append(loc.rotY);
                            toWrite.append(builder.toString()).append("\r\n");
                        }
                    }
                    reader.close();

                    writer = new FileWriter(homeLoc);
                    writer.write(toWrite.toString());
                    writer.close();
                }
            } catch (Exception e1) {
                a.log(Level.SEVERE, "Exception while editing user home in " + homeLoc, e1);
            } finally {
                try {
                    if (writer != null) {
                        writer.close();
                    }
                } catch (IOException ex) {
                }
            }
        } else {
            // User doesn't exist, woo.
            try {
                if (saveHomes) {
                    BufferedWriter bw = new BufferedWriter(new FileWriter(homeLoc, true));
                    StringBuilder builder = new StringBuilder();
                    builder.append(name);
                    builder.append(":");
                    builder.append(loc.x);
                    builder.append(":");
                    builder.append(loc.y);
                    builder.append(":");
                    builder.append(loc.z);
                    builder.append(":");
                    builder.append(loc.rotX);
                    builder.append(":");
                    builder.append(loc.rotY);
                    bw.append(builder.toString());
                    bw.newLine();
                    bw.close();
                }
                synchronized (homes) {
                    homes.put(name, loc);
                }
            } catch (Exception e2) {
                a.log(Level.SEVERE, "Exception while writing new user home to " + homeLoc, e2);
            }
        }
    }

    public void setWarp(String warpname, Location loc) {
        warpname = warpname.toLowerCase();

        if (warps.containsKey(warpname)) {
            synchronized (warps) {
                warps.put(warpname, loc);
            }
            FileWriter writer = null;
            try {
                // Now to save...
                BufferedReader reader = new BufferedReader(new FileReader(new File(warpLoc)));
                String line = "";
                StringBuilder toSave = new StringBuilder();

                while ((line = reader.readLine()) != null) {
                    if (!line.contains(warpname.toLowerCase())) {
                        toSave.append(line).append("\r\n");
                    } else {
                        StringBuilder builder = new StringBuilder();
                        builder.append(warpname.toLowerCase());
                        builder.append(":");
                        builder.append(loc.x);
                        builder.append(":");
                        builder.append(loc.y);
                        builder.append(":");
                        builder.append(loc.z);
                        builder.append(":");
                        builder.append(loc.rotX);
                        builder.append(":");
                        builder.append(loc.rotY);
                        toSave.append(builder.toString()).append("\r\n");
                    }
                }
                reader.close();

                writer = new FileWriter(warpLoc);
                writer.write(toSave.toString());
            } catch (Exception e1) {
                a.log(Level.SEVERE, "Exception while editing warp in " + warpLoc, e1);
            } finally {
                try {
                    if (writer != null) {
                        writer.close();
                    }
                } catch (IOException ex) {
                }
            }
        } else {
            // New Warp Point.
            BufferedWriter bw = null;
            try {
                bw = new BufferedWriter(new FileWriter(warpLoc, true));
                StringBuilder builder = new StringBuilder();
                builder.append(warpname.toLowerCase());
                builder.append(":");
                builder.append(loc.x);
                builder.append(":");
                builder.append(loc.y);
                builder.append(":");
                builder.append(loc.z);
                builder.append(":");
                builder.append(loc.rotX);
                builder.append(":");
                builder.append(loc.rotY);
                bw.append(builder.toString());
                bw.newLine();
                synchronized (warps) {
                    warps.put(warpname, loc);
                }
            } catch (Exception e2) {
                a.log(Level.SEVERE, "Exception while writing new warp to " + warpLoc, e2);
            } finally {
                try {
                    if (bw != null) {
                        bw.close();
                    }
                } catch (IOException ex) {
                }
            }
        }
    }

    public int getID(String item) {
        synchronized (items) {
            if (items.containsKey(item)) {
                return items.get(item);
            }
        }
        return 0;
    }

    public boolean isOnItemBlacklist(int id) {
        for (String str : itemSpawnBlacklist) {
            if (Integer.toString(id).equalsIgnoreCase(str)) {
                return true;
            }
        }
        return false;
    }

    public static String getCompassPointForDirection(double degrees) {
        if (0 <= degrees && degrees < 22.5) {
            return "N";
        } else if (22.5 <= degrees && degrees < 67.5) {
            return "NE";
        } else if (67.5 <= degrees && degrees < 112.5) {
            return "E";
        } else if (112.5 <= degrees && degrees < 157.5) {
            return "SE";
        } else if (157.5 <= degrees && degrees < 202.5) {
            return "S";
        } else if (202.5 <= degrees && degrees < 247.5) {
            return "SW";
        } else if (247.5 <= degrees && degrees < 292.5) {
            return "W";
        } else if (292.5 <= degrees && degrees < 337.5) {
            return "NW";
        } else if (337.5 <= degrees && degrees < 360.0) {
            return "N";
        } else {
            return "ERR";
        }
    }
}
