
import java.util.Map;

public class Kit {

    public String Name;
    public Map<String, Integer> IDs;
    public int Delay;
    public String Group;
}
