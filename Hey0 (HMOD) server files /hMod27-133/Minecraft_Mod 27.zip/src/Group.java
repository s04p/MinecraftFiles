
public class Group {

    public String Name;
    public String Prefix;
    public String[] Commands;
    public String[] InheritedGroups;
    public boolean DefaultGroup;
    public boolean IgnoreRestrictions;
    public boolean Administrator;
    public boolean CanModifyWorld = true;
}
