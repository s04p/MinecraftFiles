
public class Warp {

    public int ID;
    public String Name, Group;
    public Location Location;
}
