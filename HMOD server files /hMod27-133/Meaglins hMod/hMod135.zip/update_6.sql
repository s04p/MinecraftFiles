INSERT INTO `items` (`name`, `itemid`) VALUES
 ('bedblock', 26),
 ('bed', 355),
 ('redstonerepeateroff', 93),
 ('redstonerepeateron', 94),
 ('redstonerepeater', 356); 
