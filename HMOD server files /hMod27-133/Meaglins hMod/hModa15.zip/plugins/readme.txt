Place your plugins in here, then add the filename (WITHOUT the .jar) to plugins in server.properties like so:
plugins=Plugin1,Plugin2,Plugin3,etc