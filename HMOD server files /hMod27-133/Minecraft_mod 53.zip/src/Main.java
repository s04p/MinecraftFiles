
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

public class Main {

    public static void main(String[] args) throws IOException {
        if (!new File("minecraft_server.jar").exists()) {
            System.out.println("minecraft_server.jar not found, downloading...");
            BufferedInputStream istream = new BufferedInputStream(new URL("http://minecraft.net/download/minecraft_server.jar").openStream());
            FileOutputStream ostream = new FileOutputStream("minecraft_server.jar");
            byte data[] = new byte[1024];
            while (istream.read(data, 0, 1024) >= 0) {
                ostream.write(data);
            }
            ostream.close();
            istream.close();
            System.out.println("finished downloading, starting server");
        }

        net.minecraft.server.MinecraftServer.main(args);
    }
}
