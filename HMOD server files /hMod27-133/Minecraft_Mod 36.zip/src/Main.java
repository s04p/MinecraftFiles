/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author James
 */
public class Main {
    public static void main(String[] args) throws Exception {
        net.minecraft.server.MinecraftServer.main(args);
    }
}
