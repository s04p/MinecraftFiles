
import java.util.Map;

public class Kit {
    public int ID;
    public String Name;
    public Map<String, Integer> IDs;
    public int Delay;
    public String Group;
}
