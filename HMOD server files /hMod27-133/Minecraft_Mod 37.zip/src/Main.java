
public class Main {
    public static void main(String[] args) {
        try {
            net.minecraft.server.MinecraftServer.main(args);
        } catch (Exception e) {
        }
    }
}
