Copy minecraft_server.jar (get it at http://minecraft.net/download.jsp) into this bin/ and run server_gui.bat or server_nogui.bat.
Edit the newly created files accordingly.


To compile the source you will have to add minecraft_server.jar to your class path.
If using an IDE:
Eclipse:
Right click your project, hit properties. Go to build path then hit the libraries tab. Add minecraft_server.jar
Netbeans:
Right click Libraries and then Add JAR/Folder then open minecraft_server.jar