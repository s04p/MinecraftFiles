
/**
 * Colors.java- Class of all colors so I don't waste time trying to find that
 * damn character
 * 
 * @author James
 */
public class Colors {

    public static final String Black = "§0";
    public static final String Navy = "§1";
    public static final String Green = "§2";
    public static final String Blue = "§3";
    public static final String Red = "§4";
    public static final String Purple = "§5";
    public static final String Gold = "§6";
    public static final String LightGray = "§7";
    public static final String Gray = "§8";
    public static final String DarkPurple = "§9";
    public static final String LightGreen = "§a";
    public static final String LightBlue = "§b";
    public static final String Rose = "§c";
    public static final String LightPurple = "§d";
    public static final String Yellow = "§e";
    public static final String White = "§f";
}
